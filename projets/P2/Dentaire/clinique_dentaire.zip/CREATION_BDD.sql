-- ==============================================================
-- Script SQL Oracle pour la création de la base Dentissimo
-- ==============================================================

-- ==============================================================
-- Cleanup: remove existing tables/sequences/triggers to ensure clean creation
BEGIN
  FOR rec IN (
    SELECT object_name, object_type FROM user_objects
    WHERE object_type IN ('TABLE','SEQUENCE','TRIGGER')
      AND object_name IN (
        'PAIEMENT','CONSOMMABLE','ACTE_MEDICAL','TRAITEMENT','RESTAURATION','ANOMALIE','DENT','ETAT_BUCCAL','DOSSIER_MEDICAL','COMMANDE','PERSONNEL','PATIENT','EQUIPEMENT','FOURNISSEUR','FRANCHISE',
        'SEQ_FRANCHISE','SEQ_EQUIPEMENT','SEQ_PATIENT','SEQ_PERSONNEL','SEQ_DOSSIER','SEQ_TRAITEMENT','SEQ_ACTE','SEQ_ETAT','SEQ_DENT','SEQ_ANOMALIE','SEQ_RESTAURATION','SEQ_FOURNISSEUR','SEQ_CONSOMMABLE','SEQ_COMMANDE','SEQ_PAIEMENT'
      )
  ) LOOP
    BEGIN
      IF rec.object_type = 'TABLE' THEN
        EXECUTE IMMEDIATE 'DROP TABLE "'||rec.object_name||'" CASCADE CONSTRAINTS';
      ELSE
        EXECUTE IMMEDIATE 'DROP '||rec.object_type||' "'||rec.object_name||'"';
      END IF;
    EXCEPTION WHEN OTHERS THEN
      NULL; -- ignore errors
    END;
  END LOOP;
END;
/

-- ==============================================================
-- Script SQL Oracle pour la création de la base Dentissimo
-- ==============================================================

-- ==============================================================
-- SÉQUENCES : séquences d'auto-incrémentation pour les PK
-- ==============================================================

-- Le bloc suivant (déclaration d'une procédure reset_seq et appels) a été retiré car le nettoyage des objets
-- (tables / séquences / triggers) est déjà effectué dans le bloc "Cleanup" au début du script. Laisser
-- ensuite la création des séquences unique plus bas.

-- Création des séquences toutes neuves commençant à 1
CREATE SEQUENCE seq_franchise START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_equipement START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_patient START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_personnel START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_dossier START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_traitement START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_acte START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_etat START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_dent START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_anomalie START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_restauration START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_fournisseur START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_consommable START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_commande START WITH 1 INCREMENT BY 1 NOCACHE;
CREATE SEQUENCE seq_paiement START WITH 1 INCREMENT BY 1 NOCACHE;
-- ==============================================================
-- TABLE: Franchise
-- Description: informations de la franchise (identifiant, adresse, contact)  "" CA MARCHE ""
-- ==============================================================
CREATE TABLE Franchise (
    id_franchise INT PRIMARY KEY,
    nom VARCHAR2(100),
    adresse VARCHAR2(255),
    ville VARCHAR2(100),
    code_postale VARCHAR2(20),
    telephone VARCHAR2(20)
);

-- TRIGGER: trg_franchise_id
-- Description: affecte seq_franchise.NEXTVAL à id_franchise avant insertion
CREATE OR REPLACE TRIGGER trg_franchise_id
    BEFORE INSERT ON Franchise
    FOR EACH ROW
BEGIN
    IF :NEW.id_franchise IS NULL THEN
        :NEW.id_franchise := seq_franchise.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Equipement
-- Description: équipements en franchise (références ajoutées plus bas par ALTER TABLE) "" CA MARCHE ""
-- ==============================================================
CREATE TABLE Equipement (
    id_equipement INT PRIMARY KEY,
    nom VARCHAR2(100),
    type_equipement VARCHAR2(100),
    date_achat DATE,
    id_franchise INT,
    id_fournisseur INT,
    id_commande INT,
    id_consommable INT,
    CONSTRAINT fk_equipement_franchise FOREIGN KEY (id_franchise) REFERENCES Franchise(id_franchise)
    -- contraintes FK vers Fournisseur, Commande, Consommable ajoutées après création des tables référencées
);

-- TRIGGER: trg_equipement_id
-- Description: affecte seq_equipement.NEXTVAL à id_equipement avant insertion
CREATE OR REPLACE TRIGGER trg_equipement_id
    BEFORE INSERT ON Equipement
    FOR EACH ROW
BEGIN
    IF :NEW.id_equipement IS NULL THEN
        :NEW.id_equipement := seq_equipement.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Patient
-- Description: données personnelles des patients "" CA MARCHE ""
-- ==============================================================
CREATE TABLE Patient (
    id_patient INT PRIMARY KEY,
    nom VARCHAR2(100),
    prenom VARCHAR2(100),
    date_naissance DATE,
    adresse VARCHAR2(255),
    ville VARCHAR2(100),
    code_postale VARCHAR2(20),
    telephone VARCHAR2(20),
    email VARCHAR2(100)
);

-- TRIGGER: trg_patient_id
-- Description: affecte seq_patient.NEXTVAL à id_patient avant insertion
CREATE OR REPLACE TRIGGER trg_patient_id
    BEFORE INSERT ON Patient
    FOR EACH ROW
BEGIN
    IF :NEW.id_patient IS NULL THEN
        :NEW.id_patient := seq_patient.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Personnel
-- Description: personnel (interne/externe) lié à une franchise "" CA MARCHE ""
-- ==============================================================
CREATE TABLE Personnel (
    id_personnel INT PRIMARY KEY,
    nom VARCHAR2(100),
    prenom VARCHAR2(100),
    role VARCHAR2(100),
    specialite VARCHAR2(100),
    type VARCHAR2(10) CHECK (type IN ('interne', 'externe')),
    id_franchise INT,
    CONSTRAINT fk_personnel_franchise FOREIGN KEY (id_franchise) REFERENCES Franchise(id_franchise)
);

-- TRIGGER: trg_personnel_id
-- Description: affecte seq_personnel.NEXTVAL à id_personnel avant insertion
CREATE OR REPLACE TRIGGER trg_personnel_id
    BEFORE INSERT ON Personnel
    FOR EACH ROW
BEGIN
    IF :NEW.id_personnel IS NULL THEN
        :NEW.id_personnel := seq_personnel.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Dossier_Medical
-- Description: dossiers médicaux des patients (état, motif, notes) "" CA MARCHE ""
-- ==============================================================
CREATE TABLE Dossier_Medical (
    id_dossier INT PRIMARY KEY,
    date_creation DATE,
    etat VARCHAR2(10) CHECK (etat IN ('ouvert', 'ferme')),
    motif_consultation CLOB,
    notes CLOB,
    id_patient INT,
    CONSTRAINT fk_dossier_patient FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
);

-- TRIGGER: trg_dossier_id
-- Description: affecte seq_dossier.NEXTVAL à id_dossier avant insertion
CREATE OR REPLACE TRIGGER trg_dossier_id
    BEFORE INSERT ON Dossier_Medical
    FOR EACH ROW
BEGIN
    IF :NEW.id_dossier IS NULL THEN
        :NEW.id_dossier := seq_dossier.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Fournisseur
-- Description: informations des fournisseurs (contact et adresse) "" CA MARCHE ""
-- ==============================================================
CREATE TABLE Fournisseur (
    id_fournisseur INT PRIMARY KEY,
    nom VARCHAR2(100),
    adresse VARCHAR2(255),
    ville VARCHAR2(255),
    contact VARCHAR2(100),
    code_postale VARCHAR2(20),
    telephone VARCHAR2(20)
);

-- TRIGGER: trg_fournisseur_id
-- Description: affecte seq_fournisseur.NEXTVAL à id_fournisseur avant insertion
CREATE OR REPLACE TRIGGER trg_fournisseur_id
    BEFORE INSERT ON Fournisseur
    FOR EACH ROW
BEGIN
    IF :NEW.id_fournisseur IS NULL THEN
        :NEW.id_fournisseur := seq_fournisseur.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Commande
-- Description: commandes passées aux fournisseurs, lien vers fournisseur
-- ==============================================================
CREATE TABLE Commande (
    id_commande INT PRIMARY KEY,
    date_commande DATE,
    statut VARCHAR2(100),
    details_livraison CLOB,
    id_fournisseur INT,
    CONSTRAINT fk_commande_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES Fournisseur(id_fournisseur)
    );

-- TRIGGER: trg_commande_id
-- Description: affecte seq_commande.NEXTVAL à id_commande avant insertion
CREATE OR REPLACE TRIGGER trg_commande_id
    BEFORE INSERT ON Commande
    FOR EACH ROW
BEGIN
    IF :NEW.id_commande IS NULL THEN
        :NEW.id_commande := seq_commande.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Consommable
-- Description: consommables fournis par un fournisseur (stock, date de péremption)
-- ==============================================================
CREATE TABLE Consommable (
    id_consommable INT PRIMARY KEY,
    nom VARCHAR2(100),
    stock INT,
    date_peremption DATE,
    id_fournisseur INT,
    id_commande INT,
    CONSTRAINT fk_consommable_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES Fournisseur(id_fournisseur),
    CONSTRAINT fk_consommable_commande FOREIGN KEY (id_commande) REFERENCES Commande(id_commande)
);

-- TRIGGER: trg_consommable_id
-- Description: affecte seq_consommable.NEXTVAL à id_consommable avant insertion
CREATE OR REPLACE TRIGGER trg_consommable_id
    BEFORE INSERT ON Consommable
    FOR EACH ROW
BEGIN
    IF :NEW.id_consommable IS NULL THEN
        :NEW.id_consommable := seq_consommable.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Paiement
-- Description: paiements effectués par des patients, liés à un acte ou un traitement (optionnel)
-- ==============================================================
CREATE TABLE Paiement (
    id_paiement INT PRIMARY KEY,
    date_paiement DATE,
    montant NUMBER(10,2),
    mode_paiement VARCHAR2(50),
    id_patient INT,
    id_acte INT NULL,
    id_traitement INT NULL,
    CONSTRAINT fk_paiement_patient FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
);

-- TRIGGER: trg_paiement_id
-- Description: affecte seq_paiement.NEXTVAL à id_paiement avant insertion
CREATE OR REPLACE TRIGGER trg_paiement_id
    BEFORE INSERT ON Paiement
    FOR EACH ROW
BEGIN
    IF :NEW.id_paiement IS NULL THEN
        :NEW.id_paiement := seq_paiement.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Traitement
-- Description: traitements appliqués à un patient / dossier
-- ==============================================================
CREATE TABLE Traitement (
    id_traitement INT PRIMARY KEY,
    date_traitement DATE,
    cout NUMBER(10,2),
    details CLOB,
    id_patient INT,
    id_dossier INT,
    CONSTRAINT fk_traitement_patient FOREIGN KEY (id_patient) REFERENCES Patient(id_patient),
    CONSTRAINT fk_traitement_dossier FOREIGN KEY (id_dossier) REFERENCES Dossier_Medical(id_dossier)
);

-- TRIGGER: trg_traitement_id
-- Description: affecte seq_traitement.NEXTVAL à id_traitement avant insertion
CREATE OR REPLACE TRIGGER trg_traitement_id
    BEFORE INSERT ON Traitement
    FOR EACH ROW
BEGIN
    IF :NEW.id_traitement IS NULL THEN
        :NEW.id_traitement := seq_traitement.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Acte_Medical
-- Description: actes détaillés, liens vers traitement et personnel responsable
-- ==============================================================
CREATE TABLE Acte_Medical (
    id_acte INT PRIMARY KEY,
    description CLOB,
    type_acte VARCHAR2(100),
    montant NUMBER(10,2),
    radiographies CLOB,
    prescriptions CLOB,
    id_traitement INT,
    id_personnel INT,
    CONSTRAINT fk_acte_traitement FOREIGN KEY (id_traitement) REFERENCES Traitement(id_traitement),
    CONSTRAINT fk_acte_personnel FOREIGN KEY (id_personnel) REFERENCES Personnel(id_personnel)
);

-- TRIGGER: trg_acte_id
-- Description: affecte seq_acte.NEXTVAL à id_acte avant insertion
CREATE OR REPLACE TRIGGER trg_acte_id
    BEFORE INSERT ON Acte_Medical
    FOR EACH ROW
BEGIN
    IF :NEW.id_acte IS NULL THEN
        :NEW.id_acte := seq_acte.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Etat_Buccal
-- Description: relevés d'état buccal liés au patient
-- ==============================================================
CREATE TABLE Etat_Buccal (
    id_etat INT PRIMARY KEY,
    date_etat DATE,
    observations CLOB,
    id_patient INT,
    CONSTRAINT fk_etat_patient FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
);

-- TRIGGER: trg_etat_id
-- Description: affecte seq_etat.NEXTVAL à id_etat avant insertion
CREATE OR REPLACE TRIGGER trg_etat_id
    BEFORE INSERT ON Etat_Buccal
    FOR EACH ROW
BEGIN
    IF :NEW.id_etat IS NULL THEN
        :NEW.id_etat := seq_etat.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Dent
-- Description: dents identifiées par code FDI, association à un état buccal
-- ==============================================================
CREATE TABLE Dent (
    id_dent INT PRIMARY KEY,
    code_FDI VARCHAR2(10),
    etat_actuel CLOB,
    id_etat INT,
    CONSTRAINT fk_dent_etat FOREIGN KEY (id_etat) REFERENCES Etat_Buccal(id_etat)
);

-- TRIGGER: trg_dent_id
-- Description: affecte seq_dent.NEXTVAL à id_dent avant insertion
CREATE OR REPLACE TRIGGER trg_dent_id
    BEFORE INSERT ON Dent
    FOR EACH ROW
BEGIN
    IF :NEW.id_dent IS NULL THEN
        :NEW.id_dent := seq_dent.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Anomalie
-- Description: anomalies associées à une dent
-- ==============================================================
CREATE TABLE Anomalie (
    id_anomalie INT PRIMARY KEY,
    type VARCHAR2(100),
    description CLOB,
    id_dent INT,
    CONSTRAINT fk_anomalie_dent FOREIGN KEY (id_dent) REFERENCES Dent(id_dent)
);

-- TRIGGER: trg_anomalie_id
-- Description: affecte seq_anomalie.NEXTVAL à id_anomalie avant insertion
CREATE OR REPLACE TRIGGER trg_anomalie_id
    BEFORE INSERT ON Anomalie
    FOR EACH ROW
BEGIN
    IF :NEW.id_anomalie IS NULL THEN
        :NEW.id_anomalie := seq_anomalie.NEXTVAL;
    END IF;
END;
/

-- ==============================================================
-- TABLE: Restauration
-- Description: restaurations dentaires associées à une dent
-- ==============================================================
CREATE TABLE Restauration (
    id_restauration INT PRIMARY KEY,
    type_restauration VARCHAR2(100),
    date_restauration DATE,
    id_dent INT,
    CONSTRAINT fk_restauration_dent FOREIGN KEY (id_dent) REFERENCES Dent(id_dent)
);

-- TRIGGER: trg_restauration_id
-- Description: affecte seq_restauration.NEXTVAL à id_restauration avant insertion
CREATE OR REPLACE TRIGGER trg_restauration_id
    BEFORE INSERT ON Restauration
    FOR EACH ROW
BEGIN
    IF :NEW.id_restauration IS NULL THEN
        :NEW.id_restauration := seq_restauration.NEXTVAL;
    END IF;
END;
/

-- ==============================================================

-- Ajouter les contraintes FK de Equipement maintenant que les tables référencées existent
ALTER TABLE Equipement
    ADD CONSTRAINT fk_equipement_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES Fournisseur(id_fournisseur);

ALTER TABLE Equipement
    ADD CONSTRAINT fk_equipement_commande FOREIGN KEY (id_commande) REFERENCES Commande(id_commande);

ALTER TABLE Equipement
    ADD CONSTRAINT fk_equipement_consommable FOREIGN KEY (id_consommable) REFERENCES Consommable(id_consommable);

-- Ajouter les contraintes FK manquantes pour les tables référencées créées plus tard
ALTER TABLE Paiement
    ADD CONSTRAINT fk_paiement_acte FOREIGN KEY (id_acte) REFERENCES Acte_Medical(id_acte);

ALTER TABLE Paiement
    ADD CONSTRAINT fk_paiement_traitement FOREIGN KEY (id_traitement) REFERENCES Traitement(id_traitement);

-- Fin des ajouts de contraintes FK