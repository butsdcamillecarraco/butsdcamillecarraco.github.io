-- filepath: c:\Users\ccarraco\OneDrive - Université de Poitiers (1)\BUT 2\Semestre 3\SID SQL\SAE\C'est le projet en Oracle\INSERT_BDD.sql

-- Jeu de données de test pour la base Dentissimo
DECLARE
    tables SYS.ODCIVARCHAR2LIST := SYS.ODCIVARCHAR2LIST(
        'PAIEMENT',
        'CONSOMMABLE',
        'ACTE_MEDICAL',
        'TRAITEMENT',
        'RESTAURATION',
        'ANOMALIE',
        'DENT',
        'ETAT_BUCCAL',
        'DOSSIER_MEDICAL',
        'COMMANDE',
        'PERSONNEL',
        'PATIENT',
        'EQUIPEMENT',
        'FOURNISSEUR',
        'FRANCHISE'
    );
BEGIN
    FOR i IN 1..tables.COUNT LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DELETE FROM ' || tables(i);
        EXCEPTION
            WHEN OTHERS THEN
                IF SQLCODE != -942 THEN -- ignore "table does not exist"
                    RAISE;
                END IF;
        END;
    END LOOP;
    COMMIT; -- valider la suppression des données
END;
/

-- Franchise
INSERT INTO Franchise (nom, adresse, ville, code_postale, telephone) VALUES ('Dentissimo Centre', '10 rue du Sourire', 'Poitiers','86000', '0501234567');
INSERT INTO Franchise (nom, adresse, ville, code_postale, telephone) VALUES ('Dentissimo Sud', '25 avenue des Dents', 'Lyon','86000', '0509876543');
INSERT INTO Franchise (nom, adresse, ville, code_postale, telephone) VALUES ('Dentissimo Nord', '50 rue des Caries', 'Paris','86000', '0501122334');
INSERT INTO Franchise (nom, adresse, ville, code_postale, telephone) VALUES ('Dentissimo Ouest', '78 Boulevard de la Molaire', 'Angoulème','86000','0505566778');
INSERT INTO Franchise (nom, adresse, ville, code_postale, telephone) VALUES ('Dentissimo Est', '200 avenue du Microscope', 'Poitiers','86000', '0509988776');

-- Fournisseur
INSERT INTO Fournisseur (nom, adresse, ville, contact, code_postale, telephone) VALUES ('DentalPro', '1 rue du Fournisseur', 'Paris', 'dentalpro@contact.fr','75000', '0102030405');
INSERT INTO Fournisseur (nom, adresse, ville, contact, code_postale, telephone) VALUES ('MedEquip', '2 avenue Equipement', 'Lyon', 'medequip@contact.fr','69000', '0607080910');
INSERT INTO Fournisseur (nom, adresse, ville, contact, code_postale, telephone) VALUES ('SmileTech', '3 rue du Matériel', 'Bordeaux', 'smiletech@contact.fr','33000', '0506070809');
INSERT INTO Fournisseur (nom, adresse, ville, contact, code_postale, telephone) VALUES ('ProSmile', '4 rue des Outillages', 'Marseille', 'prosmile@contact.fr','13000', '0405060708');
INSERT INTO Fournisseur (nom, adresse, ville, contact, code_postale, telephone) VALUES ('OralTech', '5 avenue des Installations', 'Strasbourg', 'oraltech@contact.fr','67000', '0304050607');

-- Patient
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Martin', 'Julie', TO_DATE('1990-05-12','YYYY-MM-DD'), '5 rue des Lilas', 'Poitiers','86000', '0601020304', 'julie.martin@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Durand', 'Paul', TO_DATE('1985-11-23','YYYY-MM-DD'), '8 avenue du Sourire', 'Lyon', '69000', '0605060708', 'paul.durand@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Petit', 'Emma', TO_DATE('2012-03-08','YYYY-MM-DD'), '12 rue des Enfants', 'Marcy-Étoile', '69280', '0611223344', 'emma.petit@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Roux', 'Michel', TO_DATE('1950-09-30','YYYY-MM-DD'), '20 rue des Seniors', 'Poitiers','86000', '0611334455', 'michel.roux@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Blanc', 'Alice', TO_DATE('2000-02-14','YYYY-MM-DD'), '30 rue des Roses', 'Poitiers','86000', '0622334455', 'alice.blanc@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Vert', 'Louis', TO_DATE('1975-07-22','YYYY-MM-DD'), '40 avenue des Champs', 'Angoulème', '16000', '0622445566', 'louis.noir@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Verdi', 'Carla', TO_DATE('1988-12-05','YYYY-MM-DD'), '50 rue Verte', 'Paris', '75004', '0622556677', 'carla.verdi@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Bleu', 'Maxime', TO_DATE('2015-04-18','YYYY-MM-DD'), '60 rue Bleue', 'Poitiers','86000', '0622667788', 'maxime.bleu@mail.fr');
INSERT INTO Patient (nom, prenom, date_naissance, adresse, ville, code_postale, telephone, email) VALUES ('Violet', 'Léa', TO_DATE('1995-08-21','YYYY-MM-DD'), '70 rue des Tulipes', 'Poitiers','86000', '0622778899', 'lea.dupont@mail.fr');

-- Personnel (noms de colonnes harmonisés)
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Lefevre', 'Sophie', 'Dentiste', 'Orthodontie', 'interne',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Centre' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Bernard', 'Luc', 'Assistant', 'Hygiène', 'interne',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Sud' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Dubois', 'Claire', 'Chirurgien', 'Implantologie', 'externe',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Nord' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Moreau', 'Pierre', 'Hygiéniste', 'Prévention', 'interne',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Centre' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Simon', 'Eva', 'Dentiste', 'Pédiatrie', 'interne',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Ouest' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Giraud', 'Nina', 'Prothésiste', 'Prothèses', 'externe',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Est' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Lemoine', 'Hugo', 'Assistant', 'Accueil', 'interne',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Centre' AND ROWNUM = 1)
);
INSERT INTO Personnel (nom, prenom, role, specialite, type, id_franchise) VALUES (
  'Fontaine', 'Sarah', 'Chirurgien', 'Parodontologie', 'externe',
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Sud' AND ROWNUM = 1)
);

-- Commande
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-06-01','YYYY-MM-DD'), 'livré', TO_CLOB('Livraison rapide'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'DentalPro' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-06-10','YYYY-MM-DD'), 'en attente', TO_CLOB('Livraison prévue'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'MedEquip' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-05-20','YYYY-MM-DD'), 'en retard', TO_CLOB('Problème de transport'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'SmileTech' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-05-25','YYYY-MM-DD'), 'annulée', TO_CLOB('Annulation client'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'DentalPro' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-07-01','YYYY-MM-DD'), 'livré', TO_CLOB('Livraison express'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'ProSmile' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-07-05','YYYY-MM-DD'), 'en attente', TO_CLOB('Préparation en cours'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'OralTech' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-07-10','YYYY-MM-DD'), 'en retard', TO_CLOB('Retard fournisseur'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'MedEquip' AND ROWNUM = 1));
INSERT INTO Commande (date_commande, statut, details_livraison, id_fournisseur) VALUES (TO_DATE('2024-07-15','YYYY-MM-DD'), 'annulée', TO_CLOB('Annulation interne'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'SmileTech' AND ROWNUM = 1));

-- Dossier_Medical (doit être inséré avant Traitement)
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-06-15','YYYY-MM-DD'), 'ouvert', TO_CLOB('Contrôle annuel'), TO_CLOB('RAS'), (SELECT id_patient FROM Patient WHERE nom='Martin' AND prenom='Julie' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-06-16','YYYY-MM-DD'), 'ouvert', TO_CLOB('Douleur molaire'), TO_CLOB('À surveiller'), (SELECT id_patient FROM Patient WHERE nom='Durand' AND prenom='Paul' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2023-12-01','YYYY-MM-DD'), 'ferme', TO_CLOB('Implant'), TO_CLOB('Implant posé, suivi OK'), (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-01-15','YYYY-MM-DD'), 'ferme', TO_CLOB('Prévention'), TO_CLOB('Conseils donnés, hygiène à améliorer'), (SELECT id_patient FROM Patient WHERE nom='Petit' AND prenom='Emma' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-07-01','YYYY-MM-DD'), 'ouvert', TO_CLOB('Contrôle'), TO_CLOB('RAS'), (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-07-02','YYYY-MM-DD'), 'ouvert', TO_CLOB('Douleur'), TO_CLOB('Douleur persistante'), (SELECT id_patient FROM Patient WHERE nom='Vert' AND prenom='Louis' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-07-03','YYYY-MM-DD'), 'ferme', TO_CLOB('Prothèse'), TO_CLOB('Prothèse posée'), (SELECT id_patient FROM Patient WHERE nom='Verdi' AND prenom='Carla' AND ROWNUM=1));
INSERT INTO Dossier_Medical (date_creation, etat, motif_consultation, notes, id_patient)
VALUES (TO_DATE('2024-07-04','YYYY-MM-DD'), 'ferme', TO_CLOB('Prévention'), TO_CLOB('Conseils donnés'), (SELECT id_patient FROM Patient WHERE nom='Bleu' AND prenom='Maxime' AND ROWNUM=1));

-- Etat_Buccal
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-06-15','YYYY-MM-DD'), TO_CLOB('Bonne hygiène'), (SELECT id_patient FROM Patient WHERE nom='Martin' AND prenom='Julie' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-06-16','YYYY-MM-DD'), TO_CLOB('Inflammation gencive'), (SELECT id_patient FROM Patient WHERE nom='Durand' AND prenom='Paul' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2023-12-01','YYYY-MM-DD'), TO_CLOB('Implant posé'), (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-01-15','YYYY-MM-DD'), TO_CLOB('Plaque dentaire'), (SELECT id_patient FROM Patient WHERE nom='Petit' AND prenom='Emma' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-07-01','YYYY-MM-DD'), TO_CLOB('Bonne hygiène'), (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-07-02','YYYY-MM-DD'), TO_CLOB('Couronne posée'), (SELECT id_patient FROM Patient WHERE nom='Vert' AND prenom='Louis' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-07-03','YYYY-MM-DD'), TO_CLOB('Prothèse posée'), (SELECT id_patient FROM Patient WHERE nom='Verdi' AND prenom='Carla' AND ROWNUM=1));
INSERT INTO Etat_Buccal (date_etat, observations, id_patient) VALUES (TO_DATE('2024-07-04','YYYY-MM-DD'), TO_CLOB('Plaque dentaire'), (SELECT id_patient FROM Patient WHERE nom='Bleu' AND prenom='Maxime' AND ROWNUM=1));

-- Dent
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('11', TO_CLOB('Saine'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Martin' AND prenom='Julie' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('26', TO_CLOB('Caries'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Durand' AND prenom='Paul' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('36', TO_CLOB('Implant'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('12', TO_CLOB('Plaque'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Petit' AND prenom='Emma' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('14', TO_CLOB('Saine'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('24', TO_CLOB('Couronne'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Vert' AND prenom='Louis' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('34', TO_CLOB('Prothèse'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Verdi' AND prenom='Carla' AND ROWNUM=1) AND ROWNUM=1));
INSERT INTO Dent (code_FDI, etat_actuel, id_etat) VALUES ('44', TO_CLOB('Plaque'), (SELECT id_etat FROM Etat_Buccal WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Bleu' AND prenom='Maxime' AND ROWNUM=1) AND ROWNUM=1));

-- Anomalie (colonnes harmonisées)
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Caries', TO_CLOB('Caries profonde'), (SELECT id_dent FROM Dent WHERE code_FDI='26' AND ROWNUM=1));
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Fracture', TO_CLOB('Fracture ancienne'), (SELECT id_dent FROM Dent WHERE code_FDI='36' AND ROWNUM=1));
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Plaque', TO_CLOB('Plaque persistante'), (SELECT id_dent FROM Dent WHERE code_FDI='12' AND ROWNUM=1));
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Caries', TO_CLOB('Caries légère'), (SELECT id_dent FROM Dent WHERE code_FDI='14' AND ROWNUM=1));
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Fracture', TO_CLOB('Fracture récente'), (SELECT id_dent FROM Dent WHERE code_FDI='24' AND ROWNUM=1));
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Déchaussement', TO_CLOB('Déchaussement avancé'), (SELECT id_dent FROM Dent WHERE code_FDI='34' AND ROWNUM=1));
INSERT INTO Anomalie (type, description, id_dent) VALUES ('Plaque', TO_CLOB('Plaque persistante'), (SELECT id_dent FROM Dent WHERE code_FDI='44' AND ROWNUM=1));

-- Restauration (typo corrigée)
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Obturation', TO_DATE('2024-06-18','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='26' AND ROWNUM=1));
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Implant', TO_DATE('2023-12-01','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='36' AND ROWNUM=1));
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Détartrage', TO_DATE('2024-01-16','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='12' AND ROWNUM=1));
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Obturation', TO_DATE('2024-07-01','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='14' AND ROWNUM=1));
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Couronne', TO_DATE('2024-07-02','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='24' AND ROWNUM=1));
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Prothèse', TO_DATE('2024-07-03','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='34' AND ROWNUM=1));
INSERT INTO Restauration (type_restauration, date_restauration, id_dent) VALUES ('Détartrage', TO_DATE('2024-07-04','YYYY-MM-DD'), (SELECT id_dent FROM Dent WHERE code_FDI='44' AND ROWNUM=1));

-- Traitement (référence les dossiers créés ci-dessus)
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-06-16','YYYY-MM-DD'), 80.00, TO_CLOB('Détartrage'),
  (SELECT id_patient FROM Patient WHERE nom='Martin' AND prenom='Julie' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Martin' AND prenom='Julie' AND ROWNUM=1) AND date_creation = TO_DATE('2024-06-15','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-06-17','YYYY-MM-DD'), 150.00, TO_CLOB('Extraction molaire'),
  (SELECT id_patient FROM Patient WHERE nom='Durand' AND prenom='Paul' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Durand' AND prenom='Paul' AND ROWNUM=1) AND date_creation = TO_DATE('2024-06-16','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2023-12-02','YYYY-MM-DD'), 1200.00, TO_CLOB('Pose implant'),
  (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1) AND date_creation = TO_DATE('2023-12-01','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-01-16','YYYY-MM-DD'), 50.00, TO_CLOB('Nettoyage'),
  (SELECT id_patient FROM Patient WHERE nom='Petit' AND prenom='Emma' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Petit' AND prenom='Emma' AND ROWNUM=1) AND date_creation = TO_DATE('2024-01-15','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-07-01','YYYY-MM-DD'), 60.00, TO_CLOB('Détartrage'),
  (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1) AND date_creation = TO_DATE('2024-07-01','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-07-02','YYYY-MM-DD'), 200.00, TO_CLOB('Couronne'),
  (SELECT id_patient FROM Patient WHERE nom='Vert' AND prenom='Louis' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Vert' AND prenom='Louis' AND ROWNUM=1) AND date_creation = TO_DATE('2024-07-02','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-07-03','YYYY-MM-DD'), 800.00, TO_CLOB('Prothèse'),
  (SELECT id_patient FROM Patient WHERE nom='Verdi' AND prenom='Carla' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Verdi' AND prenom='Carla' AND ROWNUM=1) AND date_creation = TO_DATE('2024-07-03','YYYY-MM-DD') AND ROWNUM=1)
);
INSERT INTO Traitement (date_traitement, cout, details, id_patient, id_dossier)
VALUES (
  TO_DATE('2024-07-04','YYYY-MM-DD'), 40.00, TO_CLOB('Nettoyage'),
  (SELECT id_patient FROM Patient WHERE nom='Bleu' AND prenom='Maxime' AND ROWNUM=1),
  (SELECT id_dossier FROM Dossier_Medical WHERE id_patient = (SELECT id_patient FROM Patient WHERE nom='Bleu' AND prenom='Maxime' AND ROWNUM=1) AND date_creation = TO_DATE('2024-07-04','YYYY-MM-DD') AND ROWNUM=1)
);

-- Acte_Medical (utiliser la colonne 'description')
INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Détartrage complet'), 'Détartrage', 80.00, TO_CLOB('RAS'), TO_CLOB('Aucun'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Détartrage') > 0 AND cout = 80.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Lefevre' AND prenom = 'Sophie' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Extraction molaire'), 'Extraction', 150.00, TO_CLOB('Radio 2024-06-17'), TO_CLOB('Antalgique'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Extraction molaire') > 0 AND cout = 150.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Bernard' AND prenom = 'Luc' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Pose implant'), 'Implant', 1200.00, TO_CLOB('Radio 2023-12-01'), TO_CLOB('Antibiotique'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Pose implant') > 0 AND cout = 1200.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Dubois' AND prenom = 'Claire' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Nettoyage'), 'Prévention', 50.00, TO_CLOB('RAS'), TO_CLOB('Bain de bouche'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Nettoyage') > 0 AND cout = 50.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Moreau' AND prenom = 'Pierre' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Détartrage'), 'Détartrage', 60.00, TO_CLOB('RAS'), TO_CLOB('Aucun'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Détartrage') > 0 AND cout = 60.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Simon' AND prenom = 'Eva' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Pose couronne'), 'Couronne', 200.00, TO_CLOB('Radio 2024-07-02'), TO_CLOB('Antalgique'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Couronne') > 0 AND cout = 200.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Giraud' AND prenom = 'Nina' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Pose prothèse'), 'Prothèse', 800.00, TO_CLOB('Radio 2024-07-03'), TO_CLOB('Antibiotique'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Prothèse') > 0 AND cout = 800.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Lemoine' AND prenom = 'Hugo' AND ROWNUM = 1)
);

INSERT INTO Acte_Medical (description, type_acte, montant, radiographies, prescriptions, id_traitement, id_personnel)
VALUES (
  TO_CLOB('Nettoyage'), 'Prévention', 40.00, TO_CLOB('RAS'), TO_CLOB('Bain de bouche'),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Nettoyage') > 0 AND cout = 40.00 AND ROWNUM = 1),
  (SELECT id_personnel FROM Personnel WHERE nom = 'Fontaine' AND prenom = 'Sarah' AND ROWNUM = 1)
);

-- Fourniture / Consommable
-- Consommable (sans id_commande si la colonne n'existe pas dans la table)
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Gants latex', 500, TO_DATE('2025-12-31','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'DentalPro' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Seringues', 200, TO_DATE('2026-06-30','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'MedEquip' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Fil dentaire', 0, TO_DATE('2024-07-01','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'SmileTech' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Gel fluoré', 10, TO_DATE('2024-07-15','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'MedEquip' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Ciment dentaire', 30, TO_DATE('2025-08-01','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'ProSmile' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Alginates', 100, TO_DATE('2025-09-15','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'OralTech' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Compresses', 0, TO_DATE('2024-07-20','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'DentalPro' AND ROWNUM = 1));
INSERT INTO Consommable (nom, stock, date_peremption, id_fournisseur) VALUES ('Brosses', 250, TO_DATE('2026-01-01','YYYY-MM-DD'), (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'MedEquip' AND ROWNUM = 1));

-- Paiement
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-06-16','YYYY-MM-DD'), 80.00, 'CB',
  (SELECT id_patient FROM Patient WHERE nom='Martin' AND prenom='Julie' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Détartrage complet') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Détartrage') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-06-17','YYYY-MM-DD'), 150.00, 'Espèces',
  (SELECT id_patient FROM Patient WHERE nom='Durand' AND prenom='Paul' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Extraction molaire') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Extraction molaire') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-02-01','YYYY-MM-DD'), 600.00, 'Chèque',
  (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Pose implant') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Pose implant') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-02-10','YYYY-MM-DD'), 600.00, 'Virement',
  (SELECT id_patient FROM Patient WHERE nom='Roux' AND prenom='Michel' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Pose implant') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Pose implant') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-01-20','YYYY-MM-DD'), 50.00, 'CB',
  (SELECT id_patient FROM Patient WHERE nom='Petit' AND prenom='Emma' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Nettoyage') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Nettoyage') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-07-01','YYYY-MM-DD'), 60.00, 'CB',
  (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Détartrage') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Détartrage') > 0 AND id_patient = (SELECT id_patient FROM Patient WHERE nom='Blanc' AND prenom='Alice' AND ROWNUM=1) AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-07-02','YYYY-MM-DD'), 200.00, 'Espèces',
  (SELECT id_patient FROM Patient WHERE nom='Vert' AND prenom='Louis' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Couronne') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Couronne') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-07-03','YYYY-MM-DD'), 800.00, 'Chèque',
  (SELECT id_patient FROM Patient WHERE nom='Verdi' AND prenom='Carla' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Prothèse') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Prothèse') > 0 AND ROWNUM=1)
);
INSERT INTO Paiement (date_paiement, montant, mode_paiement, id_patient, id_acte, id_traitement) VALUES (
  TO_DATE('2024-07-04','YYYY-MM-DD'), 40.00, 'Virement',
  (SELECT id_patient FROM Patient WHERE nom='Bleu' AND prenom='Maxime' AND ROWNUM=1),
  (SELECT id_acte FROM Acte_Medical WHERE DBMS_LOB.INSTR(description, 'Nettoyage') > 0 AND ROWNUM=1),
  (SELECT id_traitement FROM Traitement WHERE DBMS_LOB.INSTR(details, 'Nettoyage') > 0 AND ROWNUM=1)
);



-- Diagnostic désactivé (bloc PL/SQL retiré pour éviter erreurs de syntaxe)

-- Equipement (inserts simplifiés avec id_franchise/id_fournisseur numériques)
INSERT INTO Equipement (nom, type_equipement, date_achat, id_franchise, id_fournisseur, id_commande, id_consommable)
VALUES (
  'Fauteuil dentaire', 'Fauteuil', TO_DATE('2023-01-15','YYYY-MM-DD'),
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Centre' AND ROWNUM=1),
  (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'DentalPro' AND ROWNUM=1),
  NULL, NULL
);
INSERT INTO Equipement (nom, type_equipement, date_achat, id_franchise, id_fournisseur, id_commande, id_consommable)
VALUES (
  'Lampe UV', 'Lampe', TO_DATE('2022-09-10','YYYY-MM-DD'),
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Sud' AND ROWNUM=1),
  (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'MedEquip' AND ROWNUM=1),
  NULL, NULL
);
INSERT INTO Equipement (nom, type_equipement, date_achat, id_franchise, id_fournisseur, id_commande, id_consommable)
VALUES (
  'Scanner 3D', 'Scanner', TO_DATE('2024-01-10','YYYY-MM-DD'),
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Nord' AND ROWNUM=1),
  (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'SmileTech' AND ROWNUM=1),
  NULL, NULL
);
INSERT INTO Equipement (nom, type_equipement, date_achat, id_franchise, id_fournisseur, id_commande, id_consommable)
VALUES (
  'Autoclave', 'Stérilisation', TO_DATE('2022-05-10','YYYY-MM-DD'),
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Ouest' AND ROWNUM=1),
  (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'ProSmile' AND ROWNUM=1),
  NULL, NULL
);
INSERT INTO Equipement (nom, type_equipement, date_achat, id_franchise, id_fournisseur, id_commande, id_consommable)
VALUES (
  'Microscope', 'Analyse', TO_DATE('2023-03-20','YYYY-MM-DD'),
  (SELECT id_franchise FROM Franchise WHERE nom = 'Dentissimo Est' AND ROWNUM=1),
  (SELECT id_fournisseur FROM Fournisseur WHERE nom = 'OralTech' AND ROWNUM=1),
  NULL, NULL
);

COMMIT;